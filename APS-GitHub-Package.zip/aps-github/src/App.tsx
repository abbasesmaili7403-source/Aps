import { useState, useEffect } from 'react'

type Module = 'dashboard' | 'structure' | 'environment' | 'documents' | 'projects' | 'ai'

declare global {
  interface Window { apsElectron?: { onMenuAction: (cb: (action: string) => void) => void; isElectron: boolean } }
}

const isElectron = typeof window !== 'undefined' && !!window.apsElectron

export default function App() {
  const [activeModule, setActiveModule] = useState<Module>('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(true)

  useEffect(() => {
    if (isElectron && window.apsElectron) {
      window.apsElectron.onMenuAction((action) => {
        const map: Record<string, Module> = { dashboard: 'dashboard', structure: 'structure', environment: 'environment', documents: 'documents', projects: 'projects' }
        if (map[action]) setActiveModule(map[action])
      })
    }
  }, [])

  const nav = [
    { id: 'dashboard', label: 'داشبورد', icon: '⊞' },
    { id: 'structure', label: 'طراحی سازه', icon: '⌂' },
    { id: 'environment', label: 'تحلیل محیطی', icon: '≋' },
    { id: 'documents', label: 'مستندات', icon: '⊟' },
    { id: 'projects', label: 'مدیریت پروژه', icon: '◈' },
    { id: 'ai', label: 'دستیار هوشمند', icon: '◉' },
  ] as const

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden', background: 'var(--bg-tertiary)' }}>
      {/* Sidebar */}
      <aside style={{
        width: sidebarOpen ? 220 : 56, flexShrink: 0, background: 'var(--bg-primary)',
        borderLeft: '0.5px solid var(--border)', display: 'flex', flexDirection: 'column',
        transition: 'width 0.2s', overflow: 'hidden'
      }}>
        <div style={{ padding: '14px 12px', borderBottom: '0.5px solid var(--border)', display: 'flex', alignItems: 'center', gap: 10, minHeight: 56 }}>
          <div style={{ width: 32, height: 32, background: '#0F6E56', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, color: 'white', fontSize: 16 }}>⚓</div>
          {sidebarOpen && <div>
            <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-primary)', whiteSpace: 'nowrap' }}>APS Marine</div>
            <div style={{ fontSize: 11, color: 'var(--text-secondary)', whiteSpace: 'nowrap' }}>اوج پژوهش صنعت</div>
          </div>}
        </div>
        <nav style={{ flex: 1, padding: '8px 6px', display: 'flex', flexDirection: 'column', gap: 2 }}>
          {nav.map(item => (
            <button key={item.id} onClick={() => setActiveModule(item.id as Module)}
              style={{
                display: 'flex', alignItems: 'center', gap: 10, padding: '9px 10px',
                borderRadius: 8, border: 'none', cursor: 'pointer', textAlign: 'right',
                background: activeModule === item.id ? 'var(--teal-50)' : 'none',
                color: activeModule === item.id ? 'var(--teal-800)' : 'var(--text-secondary)',
                fontWeight: activeModule === item.id ? 500 : 400,
                fontSize: 13, fontFamily: 'var(--font)', width: '100%', whiteSpace: 'nowrap'
              }}>
              <span style={{ fontSize: 16, flexShrink: 0, width: 20, textAlign: 'center' }}>{item.icon}</span>
              {sidebarOpen && item.label}
            </button>
          ))}
        </nav>
        <div style={{ padding: '10px 6px', borderTop: '0.5px solid var(--border)' }}>
          <button onClick={() => setSidebarOpen(!sidebarOpen)}
            style={{ width: '100%', padding: '8px 10px', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-tertiary)', fontSize: 18, borderRadius: 8 }}>
            {sidebarOpen ? '◁' : '▷'}
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main style={{ flex: 1, overflow: 'auto', padding: 20 }}>
        <ModuleContent module={activeModule} navigate={setActiveModule} />
      </main>
    </div>
  )
}

function ModuleContent({ module, navigate }: { module: Module; navigate: (m: Module) => void }) {
  switch (module) {
    case 'dashboard': return <Dashboard navigate={navigate} />
    case 'structure': return <StructureModule />
    case 'environment': return <EnvironmentModule />
    case 'documents': return <DocumentsModule />
    case 'projects': return <ProjectsModule />
    case 'ai': return <AIAssistant />
    default: return <Dashboard navigate={navigate} />
  }
}

// ─── Dashboard ────────────────────────────────────────────────────────────────
function Dashboard({ navigate }: { navigate: (m: Module) => void }) {
  const modules = [
    { id: 'structure' as Module, title: 'طراحی سازه دریایی', desc: 'Morison · اسکله · شمع', icon: '⌂', color: '#0F6E56', bg: '#E1F5EE' },
    { id: 'environment' as Module, title: 'تحلیل محیطی', desc: 'موج · جریان · جزر و مد', icon: '≋', color: '#185FA5', bg: '#E6F1FB' },
    { id: 'documents' as Module, title: 'مستندات فنی', desc: 'گزارش · محاسبات · نقشه', icon: '⊟', color: '#BA7517', bg: '#FAEEDA' },
    { id: 'projects' as Module, title: 'مدیریت پروژه', desc: 'گانت · تحویلی · ریسک', icon: '◈', color: '#993556', bg: '#FBEAF0' },
    { id: 'ai' as Module, title: 'دستیار هوشمند', desc: 'AI تخصصی مهندسی دریایی', icon: '◉', color: '#0F6E56', bg: '#E1F5EE' },
  ]
  const metrics = [
    { label: 'پروژه‌های فعال', value: '۵', sub: 'از ۸ کل' },
    { label: 'تحویلی این ماه', value: '۱۲', sub: '۸ تأیید شده' },
    { label: 'گزارش‌های تهیه شده', value: '۲۴', sub: 'در سال جاری' },
    { label: 'استفاده از هوش مصنوعی', value: '۴۷', sub: 'این هفته' },
  ]
  return (
    <div>
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ fontSize: 20, fontWeight: 500, color: 'var(--text-primary)', marginBottom: 4 }}>داشبورد APS Marine Platform</h1>
        <p style={{ fontSize: 13, color: 'var(--text-secondary)' }}>مهندسین مشاور اوج پژوهش صنعت · aps.ir</p>
      </div>
      <div className="grid-4" style={{ marginBottom: 20 }}>
        {metrics.map(m => (
          <div key={m.label} style={{ background: 'var(--bg-secondary)', borderRadius: 8, padding: 14 }}>
            <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 4 }}>{m.label}</div>
            <div style={{ fontSize: 22, fontWeight: 500, color: 'var(--text-primary)' }}>{m.value}</div>
            <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{m.sub}</div>
          </div>
        ))}
      </div>
      <div className="grid-3">
        {modules.map(m => (
          <div key={m.id} onClick={() => navigate(m.id)}
            style={{ background: 'var(--bg-primary)', border: '0.5px solid var(--border)', borderRadius: 12, padding: 16, cursor: 'pointer', transition: 'border-color 0.15s' }}
            onMouseEnter={e => (e.currentTarget.style.borderColor = m.color)}
            onMouseLeave={e => (e.currentTarget.style.borderColor = 'var(--border)')}>
            <div style={{ width: 40, height: 40, background: m.bg, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, marginBottom: 10 }}>{m.icon}</div>
            <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--text-primary)', marginBottom: 4 }}>{m.title}</div>
            <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{m.desc}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Structure Module ──────────────────────────────────────────────────────────
function StructureModule() {
  const [D, setD] = useState(1.2); const [H, setH] = useState(4); const [T, setT] = useState(10); const [d, setd] = useState(20)
  const [CD, setCD] = useState(1.05); const [CM, setCM] = useState(2.0)
  const g = 9.81; const omega = 2 * Math.PI / T; const k = omega * omega / g
  const u_max = (Math.PI * H / T) * (1 / Math.tanh(k * d))
  const FD = 0.5 * 1025 * CD * D * u_max * u_max / 1000
  const FI = 1025 * CM * (Math.PI * D * D / 4) * omega * u_max / 1000
  const Ftotal = Math.sqrt(FD * FD + FI * FI)
  const kD = k * D
  const Field = ({ label, value, setValue, step = 0.1, unit = '' }: any) => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
      <label style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{label} {unit && <span style={{ fontSize: 11, background: 'var(--blue-50)', color: 'var(--blue-600)', padding: '1px 6px', borderRadius: 20 }}>{unit}</span>}</label>
      <input type="number" value={value} step={step} onChange={e => setValue(parseFloat(e.target.value) || 0)}
        style={{ height: 34, padding: '0 10px', border: '0.5px solid var(--border-md)', borderRadius: 8, fontSize: 13, background: 'var(--bg-primary)', color: 'var(--text-primary)', fontFamily: 'var(--font)' }} />
    </div>
  )
  return (
    <div>
      <h2 style={{ fontSize: 18, fontWeight: 500, marginBottom: 16 }}>طراحی سازه دریایی</h2>
      <div className="card" style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 12, paddingBottom: 10, borderBottom: '0.5px solid var(--border)' }}>معادله Morison — بارگذاری هیدرودینامیکی</div>
        <div style={{ fontFamily: 'monospace', fontSize: 13, background: 'var(--bg-secondary)', padding: '8px 12px', borderRadius: 8, marginBottom: 14, borderRight: '3px solid #0F6E56' }}>
          F = ½·ρ·C_D·D·u|u| + ρ·C_M·(πD²/4)·ü
        </div>
        <div className="grid-3" style={{ marginBottom: 12 }}>
          <Field label="قطر المان D" value={D} setValue={setD} unit="m" />
          <Field label="ارتفاع موج H" value={H} setValue={setH} unit="m" />
          <Field label="پریود T" value={T} setValue={setT} step={0.5} unit="s" />
          <Field label="عمق آب d" value={d} setValue={setd} step={1} unit="m" />
          <Field label="ضریب درگ C_D" value={CD} setValue={setCD} step={0.05} />
          <Field label="ضریب اینرسی C_M" value={CM} setValue={setCM} step={0.1} />
        </div>
        <div className="grid-3">
          <div style={{ background: 'var(--bg-secondary)', borderRadius: 8, padding: 12 }}><div style={{ fontSize: 11, color: 'var(--text-secondary)', marginBottom: 4 }}>سرعت u_max</div><div style={{ fontSize: 20, fontWeight: 500 }}>{u_max.toFixed(2)}</div><div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>m/s</div></div>
          <div style={{ background: 'var(--bg-secondary)', borderRadius: 8, padding: 12 }}><div style={{ fontSize: 11, color: 'var(--text-secondary)', marginBottom: 4 }}>نیروی درگ F_D</div><div style={{ fontSize: 20, fontWeight: 500 }}>{FD.toFixed(2)}</div><div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>kN/m</div></div>
          <div style={{ background: '#E1F5EE', borderRadius: 8, padding: 12 }}><div style={{ fontSize: 11, color: '#085041', marginBottom: 4 }}>نیروی کل F</div><div style={{ fontSize: 20, fontWeight: 500, color: '#085041' }}>{Ftotal.toFixed(2)}</div><div style={{ fontSize: 11, color: '#085041' }}>kN/m</div></div>
        </div>
        {kD > 0.5
          ? <div style={{ marginTop: 10, background: '#FAEEDA', borderRadius: 8, padding: '8px 12px', fontSize: 12, color: '#633806' }}>⚠ kD = {kD.toFixed(3)} &gt; 0.5 — بررسی تئوری پراش توصیه می‌شود</div>
          : <div style={{ marginTop: 10, background: '#E1F5EE', borderRadius: 8, padding: '8px 12px', fontSize: 12, color: '#085041' }}>✓ kD = {kD.toFixed(3)} — معادله Morison مناسب است</div>}
      </div>
    </div>
  )
}

// ─── Environment Module ────────────────────────────────────────────────────────
function EnvironmentModule() {
  const [Hs, setHs] = useState(3.5); const [Tp, setTp] = useState(10)
  const g = 9.81; const L = g * Tp * Tp / (2 * Math.PI)
  const Hmax = 1.86 * Hs; const Hd = 1.8 * Hs * 1.1; const steep = Hs / L
  return (
    <div>
      <h2 style={{ fontSize: 18, fontWeight: 500, marginBottom: 16 }}>تحلیل داده‌های محیطی</h2>
      <div className="card" style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 12, paddingBottom: 10, borderBottom: '0.5px solid var(--border)' }}>پارامترهای آماری موج</div>
        <div className="grid-2" style={{ marginBottom: 12 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            <label style={{ fontSize: 12, color: 'var(--text-secondary)' }}>H_s موج معنادار (m)</label>
            <input type="number" value={Hs} step={0.1} onChange={e => setHs(parseFloat(e.target.value) || 0)} style={{ height: 34, padding: '0 10px', border: '0.5px solid var(--border-md)', borderRadius: 8, fontSize: 13, background: 'var(--bg-primary)', color: 'var(--text-primary)', fontFamily: 'var(--font)' }} />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            <label style={{ fontSize: 12, color: 'var(--text-secondary)' }}>T_p پریود اوج (s)</label>
            <input type="number" value={Tp} step={0.5} onChange={e => setTp(parseFloat(e.target.value) || 0)} style={{ height: 34, padding: '0 10px', border: '0.5px solid var(--border-md)', borderRadius: 8, fontSize: 13, background: 'var(--bg-primary)', color: 'var(--text-primary)', fontFamily: 'var(--font)' }} />
          </div>
        </div>
        <div className="grid-4">
          {[['H_max', Hmax.toFixed(2), 'm'], ['H_1/10', (1.27 * Hs).toFixed(2), 'm'], ['H_design', Hd.toFixed(2), 'm'], ['Steepness', steep.toFixed(4), '']].map(([l, v, u]) => (
            <div key={l} style={{ background: 'var(--bg-secondary)', borderRadius: 8, padding: 12 }}>
              <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginBottom: 4 }}>{l}</div>
              <div style={{ fontSize: 18, fontWeight: 500 }}>{v}</div>
              <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{u}</div>
            </div>
          ))}
        </div>
        {steep > 1 / 7 && <div style={{ marginTop: 10, background: '#FAEEDA', borderRadius: 8, padding: '8px 12px', fontSize: 12, color: '#633806' }}>⚠ Steepness &gt; 1/7 — موج در معرض شکست است</div>}
      </div>
    </div>
  )
}

// ─── Documents Module ──────────────────────────────────────────────────────────
function DocumentsModule() {
  const [projTitle, setProjTitle] = useState('طراحی اسکله چندمنظوره بندر X')
  const [client, setClient] = useState('سازمان بنادر و دریانوردی')
  const types = ['گزارش فنی', 'مشخصات فنی', 'دفترچه محاسبات', 'مکاتبه فنی', 'گزارش محیطی', 'خلاصه اجرایی']
  const [selType, setSelType] = useState(0)
  return (
    <div>
      <h2 style={{ fontSize: 18, fontWeight: 500, marginBottom: 16 }}>تهیه مستندات فنی</h2>
      <div className="card" style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 12, paddingBottom: 10, borderBottom: '0.5px solid var(--border)' }}>نوع مستند</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
          {types.map((t, i) => (
            <button key={t} onClick={() => setSelType(i)}
              style={{ padding: '6px 14px', borderRadius: 8, border: `0.5px solid ${i === selType ? '#0F6E56' : 'var(--border-md)'}`, background: i === selType ? '#E1F5EE' : 'none', color: i === selType ? '#085041' : 'var(--text-secondary)', cursor: 'pointer', fontSize: 13, fontFamily: 'var(--font)', fontWeight: i === selType ? 500 : 400 }}>
              {t}
            </button>
          ))}
        </div>
        <div className="grid-2" style={{ marginBottom: 12 }}>
          {[['عنوان پروژه', projTitle, setProjTitle], ['کارفرما', client, setClient]].map(([l, v, s]: any) => (
            <div key={l} style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
              <label style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{l}</label>
              <input value={v} onChange={e => s(e.target.value)} style={{ height: 34, padding: '0 10px', border: '0.5px solid var(--border-md)', borderRadius: 8, fontSize: 13, background: 'var(--bg-primary)', color: 'var(--text-primary)', fontFamily: 'var(--font)' }} />
            </div>
          ))}
        </div>
        <button className="btn-primary" style={{ width: '100%', justifyContent: 'center', padding: 10 }}>
          ◉ تولید {types[selType]} با هوش مصنوعی
        </button>
      </div>
    </div>
  )
}

// ─── Projects Module ───────────────────────────────────────────────────────────
function ProjectsModule() {
  const projects = [
    { name: 'اسکله چندمنظوره بندر X', client: 'سازمان بنادر', prog: 68, status: 'active' },
    { name: 'موج‌شکن شرقی بندرگاه Y', client: 'شرکت توسعه بندری', prog: 35, status: 'delay' },
    { name: 'سکوی دریایی پروژه Z', client: 'شرکت ملی نفت', prog: 95, status: 'done' },
  ]
  return (
    <div>
      <h2 style={{ fontSize: 18, fontWeight: 500, marginBottom: 16 }}>مدیریت پروژه</h2>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {projects.map(p => {
          const s = { active: { label: 'فعال', bg: '#E1F5EE', color: '#085041', bar: '#0F6E56' }, delay: { label: 'تأخیر', bg: '#FAEEDA', color: '#633806', bar: '#BA7517' }, done: { label: 'تکمیل', bg: '#E6F1FB', color: '#0C447C', bar: '#185FA5' } }[p.status]!
          return (
            <div key={p.name} style={{ background: 'var(--bg-primary)', border: '0.5px solid var(--border)', borderRadius: 12, padding: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 500 }}>{p.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{p.client}</div>
                </div>
                <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 20, background: s.bg, color: s.color }}>{s.label}</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ flex: 1, height: 6, background: 'var(--bg-secondary)', borderRadius: 3, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${p.prog}%`, background: s.bar, borderRadius: 3 }} />
                </div>
                <span style={{ fontSize: 12, color: 'var(--text-secondary)', minWidth: 36 }}>{p.prog}٪</span>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ─── AI Assistant ──────────────────────────────────────────────────────────────
function AIAssistant() {
  const [messages, setMessages] = useState<{ role: string; text: string }[]>([
    { role: 'ai', text: 'سلام! دستیار تخصصی APS آماده‌ام. سؤال مهندسی دریایی خود را بپرسید.' }
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)

  const send = async () => {
    if (!input.trim() || loading) return
    const q = input.trim(); setInput(''); setLoading(true)
    setMessages(m => [...m, { role: 'user', text: q }])
    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: 'claude-sonnet-4-6', max_tokens: 800, system: 'دستیار تخصصی مهندسی دریایی APS هستی. پاسخ‌های فنی کوتاه و کاربردی به فارسی بده. به استانداردهای BS6349، API RP 2A، DNV ارجاع بده.', messages: [{ role: 'user', content: q }] })
      })
      const data = await res.json()
      setMessages(m => [...m, { role: 'ai', text: data.content?.[0]?.text || 'خطا در دریافت پاسخ' }])
    } catch { setMessages(m => [...m, { role: 'ai', text: 'خطا در اتصال. اینترنت را بررسی کنید.' }]) }
    setLoading(false)
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 100px)' }}>
      <h2 style={{ fontSize: 18, fontWeight: 500, marginBottom: 16 }}>دستیار هوشمند APS</h2>
      <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 14 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ display: 'flex', justifyContent: m.role === 'user' ? 'flex-start' : 'flex-end' }}>
            <div style={{ maxWidth: '80%', padding: '10px 14px', borderRadius: 12, fontSize: 13, lineHeight: 1.6, background: m.role === 'user' ? '#0F6E56' : 'var(--bg-primary)', color: m.role === 'user' ? 'white' : 'var(--text-primary)', border: m.role === 'ai' ? '0.5px solid var(--border)' : 'none' }}>
              {m.text}
            </div>
          </div>
        ))}
        {loading && <div style={{ display: 'flex', justifyContent: 'flex-end' }}><div style={{ padding: '10px 14px', borderRadius: 12, background: 'var(--bg-primary)', border: '0.5px solid var(--border)', fontSize: 13, color: 'var(--text-secondary)' }}>در حال پردازش...</div></div>}
      </div>
      <div style={{ display: 'flex', gap: 10, background: 'var(--bg-primary)', border: '0.5px solid var(--border)', borderRadius: 12, padding: '10px 12px' }}>
        <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="سؤال فنی مهندسی دریایی..." style={{ flex: 1, border: 'none', background: 'none', fontSize: 13, fontFamily: 'var(--font)', color: 'var(--text-primary)', outline: 'none' }} />
        <button onClick={send} disabled={loading} className="btn-primary" style={{ padding: '6px 14px' }}>ارسال</button>
      </div>
    </div>
  )
}
