# راهنمای ساخت APK با GitHub Actions
## بدون نیاز به نصب هیچ چیزی

---

## مرحله ۱ — ساخت حساب GitHub (اگر ندارید)

1. به **github.com** بروید
2. روی **Sign up** کلیک کنید
3. ایمیل، نام کاربری و رمز وارد کنید
4. حساب را تأیید کنید

---

## مرحله ۲ — ساخت Repository جدید

1. بعد از ورود، روی **+** (بالا راست) کلیک کنید
2. **New repository** را انتخاب کنید
3. نام: `aps-marine-platform`
4. گزینه **Public** را انتخاب کنید
5. روی **Create repository** کلیک کنید

---

## مرحله ۳ — آپلود فایل‌ها

در صفحه repository جدید:

1. روی **uploading an existing file** کلیک کنید
2. فایل ZIP دانلود شده را Extract کنید
3. **همه فایل‌ها** داخل پوشه `aps-platform` را انتخاب و drag کنید
4. پایین صفحه روی **Commit changes** کلیک کنید

> ⚠️ مهم: فایل `.github/workflows/build-android.yml` حتماً باید آپلود شود

---

## مرحله ۴ — فعال کردن GitHub Actions

1. روی تب **Actions** در repository کلیک کنید
2. اگر پیام "Workflows aren't being run" دید، روی **I understand my workflows, go ahead and enable them** کلیک کنید

---

## مرحله ۵ — اجرای build

**روش اول — خودکار:**
هر بار که فایلی push کنید، build خودکار شروع می‌شود.

**روش دوم — دستی:**
1. تب **Actions** را باز کنید
2. **Build APS Android APK** را از سمت چپ انتخاب کنید
3. روی **Run workflow** کلیک کنید
4. **Run workflow** سبز را بزنید

---

## مرحله ۶ — دانلود APK

بعد از اتمام build (حدود ۱۰–۱۵ دقیقه):

1. تب **Actions** را باز کنید
2. روی آخرین workflow کلیک کنید
3. پایین صفحه بخش **Artifacts** را ببینید
4. روی **APS-Marine-Platform-APK** کلیک کنید
5. فایل ZIP دانلود می‌شود — داخل آن `APS-Marine-Platform.apk` است

---

## مرحله ۷ — نصب روی اندروید

1. فایل APK را به گوشی منتقل کنید (از طریق کابل یا Google Drive)
2. در گوشی **Settings** → **Security** → **Unknown sources** را فعال کنید
3. روی فایل APK ضربه بزنید و **Install** را بزنید

---

## نکات مهم

- **GitHub Actions رایگان است** — ماهانه ۲۰۰۰ دقیقه رایگان دارد
- **هر build حدود ۱۰–۱۵ دقیقه** طول می‌کشد
- **APK برای ۳۰ روز** در GitHub نگه داشته می‌شود
- این نسخه **Debug APK** است — برای استفاده داخلی شرکت کافی است

---

## اگر build شکست خورد

1. روی workflow کلیک کنید
2. روی **build-apk** کلیک کنید
3. مرحله‌ای که قرمز است را باز کنید
4. خطا را برای من بفرستید تا رفع کنم
