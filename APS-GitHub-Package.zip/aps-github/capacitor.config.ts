import type { CapacitorConfig } from '@capacitor/cli'

const config: CapacitorConfig = {
  appId: 'ir.aps.marine.platform',
  appName: 'APS Marine',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    cleartext: false
  },
  android: {
    buildOptions: {
      releaseType: 'APK'
    },
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false
  },
  plugins: {
    Preferences: {
      group: 'APSMarine'
    },
    Filesystem: {
      iosScheme: 'ionic'
    }
  }
}

export default config
