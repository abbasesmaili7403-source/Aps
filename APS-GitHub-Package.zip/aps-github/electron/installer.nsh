; APS Marine Platform — NSIS Custom Script
; مهندسین مشاور اوج پژوهش صنعت

!macro customInstall
  ; ایجاد shortcut روی دسکتاپ
  CreateShortCut "$DESKTOP\APS Marine Platform.lnk" "$INSTDIR\APS Marine Platform.exe" "" "$INSTDIR\APS Marine Platform.exe" 0
  ; ثبت در رجیستری ویندوز
  WriteRegStr HKLM "Software\APS\MarinePlatform" "InstallPath" "$INSTDIR"
  WriteRegStr HKLM "Software\APS\MarinePlatform" "Version" "1.0.0"
!macroend

!macro customUnInstall
  Delete "$DESKTOP\APS Marine Platform.lnk"
  DeleteRegKey HKLM "Software\APS\MarinePlatform"
!macroend
