const { app, BrowserWindow, ipcMain, shell, dialog, Menu } = require('electron')
const path = require('path')
const fs = require('fs')

const isDev = process.env.NODE_ENV === 'development' || !app.isPackaged

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    title: 'APS Marine Platform — مهندسین مشاور اوج پژوهش صنعت',
    icon: path.join(__dirname, '../public/icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webSecurity: true
    },
    titleBarStyle: 'default',
    show: false
  })

  if (isDev) {
    win.loadURL('http://localhost:5173')
    win.webContents.openDevTools()
  } else {
    win.loadFile(path.join(__dirname, '../dist/index.html'))
  }

  win.once('ready-to-show', () => {
    win.show()
    win.focus()
  })

  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url)
    return { action: 'deny' }
  })

  buildMenu(win)
}

function buildMenu(win) {
  const template = [
    {
      label: 'پرونده',
      submenu: [
        { label: 'پروژه جدید', accelerator: 'CmdOrCtrl+N', click: () => win.webContents.send('menu-action', 'new-project') },
        { label: 'ذخیره', accelerator: 'CmdOrCtrl+S', click: () => win.webContents.send('menu-action', 'save') },
        { type: 'separator' },
        { label: 'خروج', accelerator: 'Alt+F4', click: () => app.quit() }
      ]
    },
    {
      label: 'ابزار',
      submenu: [
        { label: 'داشبورد', click: () => win.webContents.send('menu-action', 'dashboard') },
        { label: 'طراحی سازه', click: () => win.webContents.send('menu-action', 'structure') },
        { label: 'تحلیل محیطی', click: () => win.webContents.send('menu-action', 'environment') },
        { label: 'مستندات', click: () => win.webContents.send('menu-action', 'documents') },
        { label: 'مدیریت پروژه', click: () => win.webContents.send('menu-action', 'projects') }
      ]
    },
    {
      label: 'نمایش',
      submenu: [
        { label: 'بزرگنمایی', accelerator: 'CmdOrCtrl+Plus', click: () => { const z = win.webContents.getZoomLevel(); win.webContents.setZoomLevel(z + 0.5) } },
        { label: 'کوچکنمایی', accelerator: 'CmdOrCtrl+-', click: () => { const z = win.webContents.getZoomLevel(); win.webContents.setZoomLevel(z - 0.5) } },
        { label: 'اندازه معمولی', accelerator: 'CmdOrCtrl+0', click: () => win.webContents.setZoomLevel(0) },
        { type: 'separator' },
        { label: 'تمام صفحه', accelerator: 'F11', click: () => win.setFullScreen(!win.isFullScreen()) }
      ]
    },
    {
      label: 'راهنما',
      submenu: [
        { label: 'درباره APS', click: () => dialog.showMessageBox(win, { type: 'info', title: 'APS Marine Platform', message: 'مهندسین مشاور اوج پژوهش صنعت\nنسخه ۱.۰.۰\naps.ir', buttons: ['بستن'] }) },
        { type: 'separator' },
        { label: 'ابزار توسعه‌دهنده', accelerator: 'F12', click: () => win.webContents.toggleDevTools() }
      ]
    }
  ]
  Menu.setApplicationMenu(Menu.buildFromTemplate(template))
}

// IPC handlers for file operations
ipcMain.handle('save-file', async (event, { filename, content, defaultPath }) => {
  const result = await dialog.showSaveDialog({
    defaultPath: path.join(defaultPath || app.getPath('documents'), filename),
    filters: [
      { name: 'PDF', extensions: ['pdf'] },
      { name: 'Word', extensions: ['docx'] },
      { name: 'همه فایل‌ها', extensions: ['*'] }
    ]
  })
  if (!result.canceled && result.filePath) {
    fs.writeFileSync(result.filePath, Buffer.from(content, 'base64'))
    return { success: true, filePath: result.filePath }
  }
  return { success: false }
})

ipcMain.handle('open-file', async (event, filters) => {
  const result = await dialog.showOpenDialog({ properties: ['openFile'], filters: filters || [] })
  if (!result.canceled && result.filePaths[0]) {
    const content = fs.readFileSync(result.filePaths[0])
    return { success: true, content: content.toString('base64'), filePath: result.filePaths[0] }
  }
  return { success: false }
})

ipcMain.handle('get-app-path', () => app.getPath('userData'))

app.whenReady().then(() => {
  createWindow()
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow() })
})

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit() })

// Auto-updater (اختیاری — برای بعد)
// const { autoUpdater } = require('electron-updater')
// app.on('ready', () => autoUpdater.checkForUpdatesAndNotify())
