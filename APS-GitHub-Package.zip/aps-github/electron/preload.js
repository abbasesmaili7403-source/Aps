const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('apsElectron', {
  saveFile: (opts) => ipcRenderer.invoke('save-file', opts),
  openFile: (filters) => ipcRenderer.invoke('open-file', filters),
  getAppPath: () => ipcRenderer.invoke('get-app-path'),
  onMenuAction: (callback) => ipcRenderer.on('menu-action', (_event, action) => callback(action)),
  platform: process.platform,
  isElectron: true
})
